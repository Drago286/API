<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Panel de Control')); ?></div>

                <div class="card-body">
                    <?php if(auth()->user()->rol === 'administrador'): ?>
                        <h2>Listado de Usuarios</h2>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Email</th>
                                    <th>SAP</th>
                                    <th>Rol</th>
                                    <th>Estado</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->SAP); ?></td>
                                        <td><?php echo e($user->rol); ?></td>
                                        <td><?php echo e($user->status); ?></td>
                                        <td>
                                            <form method="POST" action="<?php echo e(route('update.status', $user->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('POST'); ?>
                                                <input type="hidden" name="current_status" value="<?php echo e($user->status); ?>">
                                                <select name="status">
                                                    <option value="habilitado"<?php echo e($user->status === 'habilitado' ? ' selected' : ''); ?>>Habilitado</option>
                                                    <option value="deshabilitado"<?php echo e($user->status === 'deshabilitado' ? ' selected' : ''); ?>>Deshabilitado</option>
                                                </select>
                                                <button type="submit" class="btn btn-primary">Cambiar Estado</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php elseif(auth()->user()->rol === 'cliente'): ?>
                        <p>No tienes permisos para ver esta página.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/dragoperic/Desktop/asitenteV/API/resources/views/home.blade.php ENDPATH**/ ?>