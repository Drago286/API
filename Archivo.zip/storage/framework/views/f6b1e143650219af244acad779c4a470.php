<?php echo e($slot); ?>

<?php /**PATH /Users/dragoperic/Desktop/asitenteV/API/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>