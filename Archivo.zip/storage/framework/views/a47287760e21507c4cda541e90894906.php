[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /Users/dragoperic/Desktop/asitenteV/API/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>